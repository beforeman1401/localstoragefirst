// function updateTime() {
//     const now = new Date();
//     const hours = String(now.getHours()).padStart(2, '0');
//     const minutes = String(now.getMinutes()).padStart(2, '0');
//     const seconds = String(now.getSeconds()).padStart(2, '0');
//     console.log(`${hours}:${minutes}:${seconds}`);
// }

// // Har soniyada updateTime funksiyasini chaqirish
// setInterval(updateTime, 1000);

// // Dastlabki chaqiruv
// updateTime();
const telNumber=document.querySelector(".Tel");
const text=document.createElement("p");

telNumber.addEventListener("tel", display);
function display(){
    // text.innerHTML=telNumber.value;
    localStorage.setItem('value', telNumber.value);
    console.log(localStorage.getItem('value'));
}